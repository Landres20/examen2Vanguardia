﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq.Expressions;
using SolarEnergySystem.Core.Entities;

namespace SolarEnergySystem.Core.Interfaces
{
    public interface IRepository<TEntity, TKey>
    {
        void Add(TEntity entity);

        TEntity GetById(TKey key);

        IReadOnlyList<TEntity> GetAll();
    }
}
